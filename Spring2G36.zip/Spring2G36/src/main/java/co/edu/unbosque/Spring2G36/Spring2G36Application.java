package co.edu.unbosque.Spring2G36;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring2G36Application {

	public static void main(String[] args) {
		SpringApplication.run(Spring2G36Application.class, args);
	}

}
