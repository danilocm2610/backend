package co.edu.unbosque.Spring3.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import co.edu.unbosque.Spring3.model.Ventas;

public interface VentasRepository extends MongoRepository <Ventas, String> {

	
	

	List<Ventas> deleteByNombre(String nombre);
	List<Ventas> findByCedula(String cedula_Cliente);


}