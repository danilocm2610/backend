package co.edu.unbosque.spring5.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection= "Consolidado")
public class Consolidado {
	
	@Id
	private String Fecha;
	private String Ciudad;
	private double TotalDeVentas;

	
	
	
	
	public Consolidado(String fecha, String ciudad, double totalDeVentas) {
		super();
		Fecha = fecha;
		Ciudad = ciudad;
		TotalDeVentas = totalDeVentas;
	}



	public Consolidado() {
		
	}



	public String getFecha() {
		return Fecha;
	}



	public void setFecha(String fecha) {
		Fecha = fecha;
	}



	public String getCiudad() {
		return Ciudad;
	}



	public void setCiudad(String ciudad) {
		Ciudad = ciudad;
	}



	public double getTotalDeVentas() {
		return TotalDeVentas;
	}



	public void setTotalDeVentas(double totalDeVentas) {
		TotalDeVentas = totalDeVentas;
	}



	@Override
	public String toString() {
		return "Consolidado [Fecha=" + Fecha + ", Ciudad=" + Ciudad + ", TotalDeVentas=" + TotalDeVentas + "]";
	}
	
	
	
	
	
}
