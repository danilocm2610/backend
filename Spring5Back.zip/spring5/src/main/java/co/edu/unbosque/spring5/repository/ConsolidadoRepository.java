package co.edu.unbosque.spring5.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import co.edu.unbosque.spring5.model.Consolidado;

public interface ConsolidadoRepository extends MongoRepository <Consolidado, String> {

	
	

	List<Consolidado> deleteByCiudad(String nombre);

}