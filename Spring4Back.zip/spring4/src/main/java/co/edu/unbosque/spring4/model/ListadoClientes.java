package co.edu.unbosque.spring4.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection= "ListadoClientes")
	public class ListadoClientes {
	
	@Id
	private String Nombre_Cliente;
	private String Correo_Cliente;
	private int Telefono_Cliente;
	
	
	public ListadoClientes() {
		
	}
	
	
	
	
	public ListadoClientes(String nombre_Cliente, String correo_Cliente, int telefono_Cliente) {
		super();
		Nombre_Cliente = nombre_Cliente;
		Correo_Cliente = correo_Cliente;
		Telefono_Cliente = telefono_Cliente;
	}




	public String getNombre_Cliente() {
		return Nombre_Cliente;
	}
	public void setNombre_Cliente(String nombre_Cliente) {
		Nombre_Cliente = nombre_Cliente;
	}
	public String getCorreo_Cliente() {
		return Correo_Cliente;
	}
	public void setCorreo_Cliente(String correo_Cliente) {
		Correo_Cliente = correo_Cliente;
	}
	public int getTelefono_Cliente() {
		return Telefono_Cliente;
	}
	public void setTelefono_Cliente(int telefono_Cliente) {
		Telefono_Cliente = telefono_Cliente;
	}




	@Override
	public String toString() {
		return "ListadoClientes [Nombre_Cliente=" + Nombre_Cliente + ", Correo_Cliente=" + Correo_Cliente
				+ ", Telefono_Cliente=" + Telefono_Cliente + "]";
	}

	
	
}
