package co.edu.unbosque.spring4.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection= "TotalVentas")
public class TotalVentas {
	
	
	@Id
	private int ValorProducto;
	private int IvaProducto;
	private int CodigoProducto;
	private int TotalProducto;
	
	
	
	public TotalVentas() {
		
	}


	
	
	
	

	public TotalVentas(int valorProducto, int ivaProducto, int codigoProducto, int totalProducto) {
		super();
		ValorProducto = valorProducto;
		IvaProducto = ivaProducto;
		CodigoProducto = codigoProducto;
		TotalProducto = totalProducto;
	}







	public int getValorProducto() {
		return ValorProducto;
	}



	public void setValorProducto(int valorProducto) {
		ValorProducto = valorProducto;
	}



	public int getIvaProducto() {
		return IvaProducto;
	}



	public void setIvaProducto(int ivaProducto) {
		IvaProducto = ivaProducto;
	}



	public int getCodigoProducto() {
		return CodigoProducto;
	}



	public void setCodigoProducto(int codigoProducto) {
		CodigoProducto = codigoProducto;
	}



	public int getTotalProducto() {
		return TotalProducto;
	}



	public void setTotalProducto(int totalProducto) {
		TotalProducto = totalProducto;
	}







	@Override
	public String toString() {
		return "TotalVentas [ValorProducto=" + ValorProducto + ", IvaProducto=" + IvaProducto + ", CodigoProducto="
				+ CodigoProducto + ", TotalProducto=" + TotalProducto + "]";
	}
	
	
	

}
