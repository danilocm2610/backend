package co.edu.unbosque.spring4.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import co.edu.unbosque.spring4.controller.Reportes;

public interface ReportesRepository  extends MongoRepository <Reportes, String> {
	
	List<Reportes> findByNombre(String nombre);


}
