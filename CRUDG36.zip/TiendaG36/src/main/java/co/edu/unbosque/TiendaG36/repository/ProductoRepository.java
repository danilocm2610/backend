package co.edu.unbosque.TiendaG36.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import co.edu.unbosque.TiendaG36.model.*;;

public interface ProductoRepository extends MongoRepository<Producto, String>{
	
	List<Producto> findByNombre(String nombre);

	List<Producto> deleteByNombre(String nombre);
		
}


