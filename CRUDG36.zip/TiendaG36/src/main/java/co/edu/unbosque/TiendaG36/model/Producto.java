package co.edu.unbosque.TiendaG36.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


	@Document(collection = "productos")
	public class Producto {
		
		 @Id
		  private String id;
		 
		private String nombre;
		
		private Float precio;
		
		private Float peso;
		
		
		
		

		public Producto() {
			
		}

		public Producto(String nombre, Float precio, Float peso) {
			super();
			this.nombre = nombre;
			this.precio = precio;
			this.peso = peso;
		}

		

		public String getId() {
			return id;
		}

		public void setId(String id) {
			this.id = id;
		}

		public String getNombre() {
			return nombre;
		}

		public void setNombre(String nombre) {
			this.nombre = nombre;
		}

		public Float getPrecio() {
			return precio;
		}

		public void setPrecio(Float precio) {
			this.precio = precio;
		}

		public Float getPeso() {
			return peso;
		}

		public void setPeso(Float peso) {
			this.peso = peso;
		}

		@Override
		public String toString() {
			return "Producto [id=" + id + ", nombre=" + nombre + ", precio=" + precio + ", peso=" + peso + "]";
		}
		
		
}
	