package co.edu.unbosque.TiendaG36;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TiendaG36ApplicationTests {

	@Test
	void contextLoads() {
	}

}
